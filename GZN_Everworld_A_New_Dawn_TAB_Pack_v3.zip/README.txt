GZN Everworld TAB Pack V3
Logo is at glyph U+E002. Large 70px bitmap shifted down (ascent 50).
Install the V3 pack in Minecraft and the matching V3 TAB config.yml on the server.
Deactivate V2 when testing V3. TAB reload: /tab reload.
No server resource-pack setting changed automatically.
